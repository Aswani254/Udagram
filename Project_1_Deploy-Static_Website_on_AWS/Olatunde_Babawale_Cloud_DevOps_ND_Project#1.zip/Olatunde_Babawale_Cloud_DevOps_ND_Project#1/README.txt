In this project, I hosted a static website on AWS using the static hosting feature of Amazon Simple Storage Service (S3), CloudFront, and IAM.

The uploaded folders and files are: 

Unmodified folders
/vendor - Bootstrap CSS framework, Font, and JavaScript libraries needed for the website to function (provided as part of the starter files).

/css - CSS files for the website (provided as part of the starter files).

Modified
index.html - The Index document for the website edited to include personal name and background photo

/img - Folder containing the new background image

README.txt - This document

The following screenshots are included in the zipped folder:

### Bucket Details
-"1_S3Bucket.png": Shows S3 bucket in the Management Console

-"2_S3BucketContents.png": Shows the contents of the S3 bucket

-"3_S3_IAM_Permission_Policy.png": Shows the IAM policy attached to the bucket.

-"4_BucketEnabledforStaticHosting.png": Shows that the S3 Bucket was enabled to support static website hosting.

-"5_URLforStaticSite.png": Shows the website-endpoint


### Cloud Front Details
-"6_CloudFrontDomainName.png": Shows the CloudFront distribution domain name.
-"7_CloudFrontDistroEnabled.png": Shows the CloudFront distribution is enabled.

### Screenshot of website
-"8_WebsiteFromBucketName.png": Shows the website accessed from S3 URL.
-"9_WebsiteFromEndPoint.png": Shows the website accessed from the website-endpoint.
-"10_WebsiteFromCloudFrontDomainName.png": Shows the website accessed from the Cloud Front Distribution Domain Name.


### Accessing the Website.

Using the CloudFront Domain Name: https://demoz9izicld2.cloudfront.net/

Using the bucket S3 object URL: https://babawale-udacity-static-site.s3.amazonaws.com/index.html

Using the website-endpoint: http://babawale-udacity-static-site.s3-website-us-east-1.amazonaws.com/